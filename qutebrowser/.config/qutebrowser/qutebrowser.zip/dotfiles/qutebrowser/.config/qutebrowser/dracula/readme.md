# Dracula for [qutebrowser](https://www.qutebrowser.org/)

> A dark theme for [qutebrowser](https://www.qutebrowser.org/).

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/qutebrowser](https://draculatheme.com/qutebrowser).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/qutebrowser/graphs/contributors).

[![Evan Nagle](https://avatars2.githubusercontent.com/u/556537?s=88&v=4&s=70)](https://github.com/evannagle) |
--- |
[Evan Nagle](https://github.com/evannagle) |

## License

[MIT License](./LICENSE)
